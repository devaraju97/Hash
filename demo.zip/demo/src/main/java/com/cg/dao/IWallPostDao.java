package com.cg.dao;

import com.cg.bean.WallPost;

import org.springframework.data.jpa.repository.JpaRepository;

public interface IWallPostDao extends JpaRepository<WallPost,Integer>{

	  

}
