package com.cg.services;

import com.cg.bean.WallPost;

public interface IWallPostService {

	WallPost addWallPost(WallPost wallpost);
}
