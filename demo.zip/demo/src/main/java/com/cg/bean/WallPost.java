package com.cg.bean;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "WALLPOST1")
public class WallPost {

	@Id
	@GeneratedValue
	private int id;
	// @Pattern(regexp="[A-Z][a-z]*")
	@Column
	private String wallpost;

	private Timestamp createdDate;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getWallpost() {
		return wallpost;
	}

	public void setWallpost(String wallpost) {
		this.wallpost = wallpost;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	@Override
	public String toString() {
		return "WallPost [id=" + id + ", wallpost=" + wallpost + ", createdDate=" + createdDate + "]";
	}

}
